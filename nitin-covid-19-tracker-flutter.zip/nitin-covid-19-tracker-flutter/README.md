# nitin-covid-19-tracker-flutter

graph.dart and main.dart files under /corona_tracker/lib/ contains all the logic related to the app, check pubspec.yaml for looking at the external dependencies.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.





Final Display

![covid-19 tracker](https://github.com/learningdollars/nitin-covid-19-tracker-flutter/blob/master/corona_tracker/images/Screenshot_20200419-233022.jpg?v=4&s=200)
![covid-19 tracker](https://github.com/learningdollars/nitin-covid-19-tracker-flutter/blob/master/corona_tracker/images/Screenshot_20200419-233028.jpg?v=4&s=200)

